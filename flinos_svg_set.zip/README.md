# FLiNOS SVG logo set

Vector variants for the FLiNOS branding exploration.

Palette:
- Denim: #315A91
- Dark denim: #1F3F6B
- Near black: #05070A
- White: #F5F7FA

The wordmark and tagline are SVG text and remain editable. Exact rendering depends on fonts installed in the application.
